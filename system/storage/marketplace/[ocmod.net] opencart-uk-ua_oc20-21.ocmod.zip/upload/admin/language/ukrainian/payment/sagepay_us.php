<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']					= 'Платіжна система SagePay(US)';

// Text
$_['text_payment']					= 'Платіж';
$_['text_success']					= 'Ви успішно змінили модeль SagePay!';
$_['text_edit']                     = 'Змінити Sage Payment Solutions (US)';

// Entry
$_['entry_merchant_id']				= 'ID продавця';
$_['entry_merchant_key']			= 'Ключ продавця';
$_['entry_total']					= 'Загалом';
$_['entry_order_status']			= 'Статус замовлення';
$_['entry_geo_zone']				= 'Гео зона';
$_['entry_status']					= 'Статус';
$_['entry_sort_order']				= 'Порядок сортування';

// Help
$_['help_total']					= 'Мінімальна сума замовлення, при якій можна буде використати цей спосіб оплати.';

// Error
$_['error_permission']				= 'У Вас немає доступу до зміни модулю SagePay!';
$_['error_merchant_id']				= 'Необхідне ID продавця!';
$_['error_merchant_key']			= 'Необхідний ключ продавця!';