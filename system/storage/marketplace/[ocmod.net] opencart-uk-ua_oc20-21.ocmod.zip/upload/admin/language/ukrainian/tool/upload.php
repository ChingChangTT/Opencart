<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']     = 'Завантаження';

// Text
$_['text_success']      = 'Ви успішно змінили завантаження!';
$_['text_list']         = 'Список завантажень';

// Column
$_['column_name']       = 'Назва завантаження';
$_['column_filename']   = 'Назва файлу';
$_['column_date_added'] = 'Дата додавання';
$_['column_action']     = 'Дія';

// Entry
$_['entry_name']        = 'Назва завантаження';
$_['entry_filename']    = 'Назва файлу';
$_['entry_date_added'] 	= 'Дата додавання';

// Error
$_['error_permission']  = 'Увага: У Вас немає доступу для зміни завантажень!';