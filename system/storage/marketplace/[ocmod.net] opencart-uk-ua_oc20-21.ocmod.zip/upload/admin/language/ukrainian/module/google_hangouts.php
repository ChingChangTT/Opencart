<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']    = 'Google Hangouts';

// Text
$_['text_module']      = 'Модулі';
$_['text_success']     = 'Ви успішно змінили модуль Google Hangouts!';
$_['text_edit']        = 'Змінити модуль Google Hangouts';

// Entry
$_['entry_code']       = 'Google Talk Код';
$_['entry_status']     = 'Статус';

// Help
$_['help_code']        = 'Goto <a href="https://developers.google.com/+/hangouts/button" target="_blank">Створити Google Hangout chatback бейдж</a> і скопіюйте, а потім вставте згенерований код в текстове поле.';

// Error
$_['error_permission'] = 'У Вас немає доступу до зміни модулю Google Hangouts!';
$_['error_code']       = 'Код потрібно!';