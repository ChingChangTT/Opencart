<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']     = 'Вітрина eBay';

// Text
$_['text_module']       = 'Модулі';
$_['text_success']      = 'Ви успішно змінили модуль вітрини eBay!';
$_['text_list']         = 'Список макетів';
$_['text_start_newest'] = 'Час початку останнього';
$_['text_start_random'] = 'Випадково';

// Entry
$_['entry_limit']       = 'Межа';
$_['entry_image']       = 'Зображення (Ш x В)';
$_['entry_username']    = 'Ім’я користувача eBay';
$_['entry_keywords']    = 'Ключові слова для пошуку';
$_['entry_description'] = 'Включити пошук в описі';
$_['entry_site']   		= 'Сайт eBay';

// Error
$_['error_permission']  = 'У Вас намає доступу до зміни вітрини eBay!';
$_['error_image']       = 'Необхідно вказати ширину і висоту зображення!';