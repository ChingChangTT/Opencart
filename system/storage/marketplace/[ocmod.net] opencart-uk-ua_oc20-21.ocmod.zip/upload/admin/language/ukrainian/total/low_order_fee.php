<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']    = 'Комісія за маленьке замовлення';

// Text
$_['text_total']       = 'Замовлення загалом';
$_['text_success']     = 'Ви успішно змінили комісію за маленьке замовлення!';
$_['text_edit']        = 'Змінити загальну суму комісії за маленьке замовлення';

// Entry
$_['entry_total']      = 'Замовлення загалом';
$_['entry_fee']        = 'Комісія';
$_['entry_tax_class']  = 'Клас податку';
$_['entry_status']     = 'Статус';
$_['entry_sort_order'] = 'Порядок сортування';

// Help
$_['help_total']       = 'Сума замовлення,при досягенні якої замовлення стає активним.';

// Error
$_['error_permission'] = 'У Вас немає доступу для зміни Комісії за  маленьке замовлення!';