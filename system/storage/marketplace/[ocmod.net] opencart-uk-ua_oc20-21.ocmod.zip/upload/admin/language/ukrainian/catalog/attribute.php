<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']          = 'Атрибути';

// Text
$_['text_success']           = 'Ви успішно змінили атрибути!';
$_['text_list']              = 'Список атрибут';
$_['text_add']               = 'Додати атрибут';
$_['text_edit']              = 'Змінити атрибут';

// Column
$_['column_name']            = 'Назва атрибуту';
$_['column_attribute_group'] = 'Група атрибутів';
$_['column_sort_order']      = 'Порядок сортування';
$_['column_action']          = 'Дія';

// Entry
$_['entry_name']            = 'Назва атрибуту';
$_['entry_attribute_group'] = 'Група атрибутів';
$_['entry_sort_order']      = 'Порядок сортування';

// Error
$_['error_permission']      = 'Увага: У Вас немає доступу для зміни атрибутів!';
$_['error_name']            = 'Назва атрибуту повинна містити від 3 до 64 символів!';
$_['error_product']         = 'Увага: цей атрибут не можна видалити, в даний момент він використовується в товарі %s!';