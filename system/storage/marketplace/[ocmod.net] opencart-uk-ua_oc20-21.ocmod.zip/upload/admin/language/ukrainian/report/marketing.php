<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']    = 'Маркетинговий звіт';

// Text
$_['text_list']         = 'Список маркетингу';
$_['text_all_status']   = 'Всі статуси';

// Column
$_['column_campaign']  = 'Назва кампанії';
$_['column_code']      = 'Код';
$_['column_clicks']    = 'Кліки';
$_['column_orders']    = 'Кількість замовлень';
$_['column_total']     = 'Загалом';

// Entry
$_['entry_date_start'] = 'Дата початку';
$_['entry_date_end']   = 'Дата закінчення';
$_['entry_status']     = 'Статус замовлення';