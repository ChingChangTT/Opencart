<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']     = 'Теми сертифікатів';

// Text
$_['text_success']      = 'Ви успішно змінили Теми Сертифікатів!';
$_['text_list']         = 'Список Тем сертифікатів';
$_['text_add']          = 'Додати тему сертифікату';
$_['text_edit']         = 'Змінити тему сертифікату';

// Column
$_['column_name']       = 'Назва теми Сертифікату';
$_['column_action']     = 'Дія';

// Entry
$_['entry_name']        = 'Назва теми Сертифікату';
$_['entry_description'] = 'Опис теми Сертифікату';
$_['entry_image']       = 'Зображення';

// Error
$_['error_permission']  = 'У Вас немає доступу до зміни Тем Сертифікатів!';
$_['error_name']        = 'Назва теми Сертифікату повинна містити від 3 до 32 символів!';
$_['error_image']       = 'Необхідно додати зображення!';
$_['error_voucher']     = 'Ця тема Сертифікату не може бути видалена, оскільки вона використовується в %s Сертифікатах!';