<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Text
$_['text_subject']  = '%s - Запит скидання паролю';
$_['text_greeting'] = 'Запит нового паролю для %s було відправлено.';
$_['text_change']   = 'Для скидання паролю натисніть на наступне посилання:';
$_['text_ip']       = 'IP адреса з якої було зроблено запит була наступна: %s';