<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']     = 'Доставка';

// Text
$_['text_success']      = 'Ви успішно змінили доставку!';
$_['text_list']         = 'Список доставок';

// Column
$_['column_name']       = 'Метод доставки';
$_['column_status']     = 'Статус';
$_['column_sort_order'] = 'Порядок сортування';
$_['column_action']     = 'Дія';

// Error
$_['error_permission']  = 'У Вас немає доступу для зміни доставки!';