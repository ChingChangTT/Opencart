<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']     = 'Звіт з комісій партнерської програми';

// Text
$_['text_list']         = 'Список комісій партнерської програми';

// Column
$_['column_affiliate']  = 'Ім’я партнера';
$_['column_email']      = 'E-Mail';
$_['column_status']     = 'Статус';
$_['column_commission'] = 'Комісія';
$_['column_orders']     = 'Кількість замовлень';
$_['column_total']      = 'Загалом';
$_['column_action']     = 'Дія';

// Entry
$_['entry_date_start']  = 'Дата початку';
$_['entry_date_end']    = 'Дата закінчення';