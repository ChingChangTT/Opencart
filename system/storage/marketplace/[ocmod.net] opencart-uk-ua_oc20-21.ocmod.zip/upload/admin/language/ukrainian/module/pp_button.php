<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']    = 'Кнопка експрес оплати PayPal';

// Text
$_['text_module']      = 'Модулі';
$_['text_success']     = 'Ви успішно змівнили модуль Кнопки експрес оплати PayPal!';
$_['text_edit']        = 'Змінити модуль Кнопка експрес оплати PayPal';

// Entry
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'У Вас немає доступу до зміни модулю Кнопка експрес оплати PayPal!';