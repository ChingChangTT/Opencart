<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']    = 'Звіт про перегляд товарів';

// Text
$_['text_list']        = 'Список переглянутих товарів';
$_['text_success']     = 'Ви успішно скинули звіт про переглянуті товари!';

// Column
$_['column_name']      = 'Назва товару';
$_['column_model']     = 'Модель';
$_['column_viewed']    = 'Переглянуто';
$_['column_percent']   = 'Відсоток';

// Error
$_['error_permission'] = 'У Вас немає доступу до скидання звіту про переглянуті товари!';