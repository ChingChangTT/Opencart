<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']    = 'Новинки';

// Text
$_['text_module']      = 'Модулі';
$_['text_success']     = 'Ви успішно змінили модуль Новинки!';
$_['text_edit']        = 'Змінити модуль Новинки';

// Entry
$_['entry_limit']      = 'Обмеження';
$_['entry_image']      = 'Зораження (Ш x В) і зміна розміру';
$_['entry_width']      = 'Ширина';
$_['entry_height']     = 'Висота';
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'У Вас неає доступу до зміни модулю Новинки!';
$_['error_image']      = 'Вкажіть ширину і висоту зображення!';