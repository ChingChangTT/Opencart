<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']    = 'Канали товарів';

// Text
$_['text_success']     = 'Ви успішно змінили канали товарів!';
$_['text_list']        = 'Список каналів';

// Column
$_['column_name']      = 'Назва каналу товарів';
$_['column_status']    = 'Статус';
$_['column_action']    = 'Дія';

// Error
$_['error_permission'] = 'У вас немає доступу для зміни каналів товарів!';