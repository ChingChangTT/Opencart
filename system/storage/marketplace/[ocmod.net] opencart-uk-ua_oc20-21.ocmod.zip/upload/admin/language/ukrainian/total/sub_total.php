<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']    = 'Сума';

// Text
$_['text_total']       = 'Замовлення загалом';
$_['text_success']     = 'Ви успішно змінили Суму!';
$_['text_edit']        = 'Змінити Суму';

// Entry
$_['entry_status']     = 'Статус';
$_['entry_sort_order'] = 'Порядок сортування';

// Error
$_['error_permission'] = 'У Вас немає доступу для зміни Суми!';