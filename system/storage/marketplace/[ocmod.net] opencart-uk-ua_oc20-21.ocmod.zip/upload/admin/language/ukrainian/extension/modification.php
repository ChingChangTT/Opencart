<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']     = 'Модифікації';

// Text
$_['text_success']      = 'Ви успішно змінили модифікації!';
$_['text_refresh']      = 'Кожного разу при включенні/виключенні чи видаленні можифікації необхідно натискати кнопку перезавантаження для поновлення кешу модифікацій!';
$_['text_list']         = 'Список модифікацій';

// Column
$_['column_name']       = 'Назва модифікації';
$_['column_author']     = 'Автор';
$_['column_version']    = 'Версія';
$_['column_status']     = 'Статус';
$_['column_date_added'] = 'Дата додавання';
$_['column_action']     = 'Дія';

// Error
$_['error_permission']  = 'У Вас немає доступу до зміни модифікацій!';