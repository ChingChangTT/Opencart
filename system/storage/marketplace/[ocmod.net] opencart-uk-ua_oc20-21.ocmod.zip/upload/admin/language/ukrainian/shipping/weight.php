<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']    = 'Доставка в залежності від ваги';

// Text
$_['text_shipping']    = 'Доставка';
$_['text_success']     = 'Ви успішно змінили Доставку в залежності від ваги!';
$_['text_edit']        = 'Змінити Доставку в залежності від ваги';

// Entry
$_['entry_rate']       = 'Тарифи';
$_['entry_tax_class']  = 'Класи податків';
$_['entry_geo_zone']   = 'Гео зони';
$_['entry_status']     = 'Статус';
$_['entry_sort_order'] = 'Порядок сортування';

// Help
$_['help_rate']        = 'Приклад: 5:10.00,7:12.00 Вага:Вартість,Вага:Вартість, і т.д.';

// Error
$_['error_permission'] = 'У Вас немає доступу до зміни Доставки в залежності від ваги!';