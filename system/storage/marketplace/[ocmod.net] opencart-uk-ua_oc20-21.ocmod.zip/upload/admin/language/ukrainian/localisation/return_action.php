<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']    = 'Дії з поверненням';

// Text
$_['text_success']     = 'Ви успішно змінили Дії з поверенням!';
$_['text_list']        = 'Список дій з поверення';
$_['text_add']         = 'Додати дію з повернення';
$_['text_edit']        = 'Змінити дію з повернення';

// Column
$_['column_name']      = 'Назва дії з повернення';
$_['column_action']    = 'Дія';

// Entry
$_['entry_name']       = 'Назва дії з повернення';

// Error
$_['error_permission'] = 'У Вас немає доспуту до зміни дій з повернення!';
$_['error_name']       = 'Назва дії з повернення повинна містити від 3 до 64 символів!';
$_['error_return']     = 'Цю дію з повернення неможливо видалити оскільки зараз вона використовується в %s повернутих товарах!';