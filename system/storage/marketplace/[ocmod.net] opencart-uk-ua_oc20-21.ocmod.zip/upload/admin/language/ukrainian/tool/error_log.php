<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']	   = 'Журнал помилок';

// Text
$_['text_success']	   = 'Ви успішно очистили Ваш журнал помилок!';
$_['text_list']        = 'Список помилок';

// Error
$_['error_warning']	   = 'Увага: Файл Вашого журналу помилок %s є %s!';
$_['error_permission'] = 'У Вас немає доступу для очищення журналу помилок!';