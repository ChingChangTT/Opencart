<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']     = 'Звіт про кількість покупців на сайті';

// Text
$_['text_list']         = 'Список покупців на сайті';
$_['text_guest']        = 'Гість';

// Column
$_['column_ip']         = 'IP';
$_['column_customer']   = 'Покупець';
$_['column_url']        = 'Остання відкрита сторінка';
$_['column_referer']    = 'Реферер';
$_['column_date_added'] = 'Останній клік';
$_['column_action']     = 'Дія';

// Entry
$_['entry_ip']          = 'IP';
$_['entry_customer']    = 'Покупець';