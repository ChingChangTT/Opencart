<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']    = 'Обліковий запис';

$_['text_module']      = 'Модулі';
$_['text_success']     = 'Ви успішно змінили модуль облікового запису!';
$_['text_edit']        = 'Змінити модуль облікового запису';

// Entry
$_['entry_status']     = 'Статус';

// Error
$_['error_permission'] = 'У Вас немає доступу для зміни модулю облікового запису!';