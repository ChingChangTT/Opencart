<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']    = 'Резервне копіювання і відновлення';

// Text
$_['text_backup']      = 'Завантажити резервну копію';
$_['text_success']     = 'Ви успішно імпортували Вашу базу даних!';
$_['text_list']        = 'Список завантажень';

// Entry
$_['entry_restore']    = 'Відновити резервну копію';
$_['entry_backup']     = 'Резервна копія';

// Error
$_['error_permission'] = 'У Вас немає доступу для зміни резервних копій!';
$_['error_backup']     = 'Увага: Ви мусите обрати як мінімум одну базу для резервного копіювання!';
$_['error_empty']      = 'Увага: Файл який Ви завантажили був порожній!';