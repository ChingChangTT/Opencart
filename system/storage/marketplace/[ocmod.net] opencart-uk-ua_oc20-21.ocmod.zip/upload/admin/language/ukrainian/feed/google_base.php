<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']    = 'Google Base';

// Text
$_['text_feed']        = 'Канали товарів';
$_['text_success']     = 'Ви успішно змінили канал Google Base!';
$_['text_list']        = 'Список макету';

// Entry
$_['entry_status']     = 'Статус';
$_['entry_data_feed']  = 'Мережева адреса';

// Error
$_['error_permission'] = 'У Вас немає доступу для зміни каналу Google Base!';