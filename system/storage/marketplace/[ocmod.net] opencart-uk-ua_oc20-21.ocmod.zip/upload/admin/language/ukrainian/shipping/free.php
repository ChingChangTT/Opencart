<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']    = 'Безкоштовна доставка';

// Text
$_['text_shipping']    = 'Доставка';
$_['text_success']     = 'Ви успішно змінили Безкоштовну доставку!';
$_['text_edit']        = 'Змінити Безкоштовну доставку';

// Entry
$_['entry_total']      = 'Загалом';
$_['entry_geo_zone']   = 'Гео зона';
$_['entry_status']     = 'Статус';
$_['entry_sort_order'] = 'Порядок сортування';

// Help
$_['help_total']       = 'Сума замовлення, яка необхідна для активації модулю Безкоштовної доставки.';

// Error
$_['error_permission'] = 'У Вас немає доступу до зміни Безкоштовної доставки!';