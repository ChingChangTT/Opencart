<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Text
$_['text_footer'] 	= '<a href="http://www.opencart.com">OpenCart</a> &copy; 2009-' . date('Y') . ' Всі права зарезервовано.';
$_['text_version'] 	= 'Версія %s';