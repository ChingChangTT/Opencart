<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua


// Heading
$_['heading_title']	  = 'OpenBay Pro';

// Text
$_['text_module']    = 'Модулі';
$_['text_installed'] = 'Модуть OpenBay Pro встановлено. Він знаходиться "Розширення" -> "OpenBay Pro"';