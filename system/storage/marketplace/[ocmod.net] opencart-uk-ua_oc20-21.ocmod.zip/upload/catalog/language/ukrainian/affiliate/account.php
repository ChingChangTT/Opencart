<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']        = 'Моя партнерська програма';

// Text
$_['text_account']         = 'Обліковий запис';
$_['text_my_account']      = 'Мій партнерський обліковий запис';
$_['text_my_tracking']     = 'Мої відстеження';
$_['text_my_transactions'] = 'Мої транзакції';
$_['text_edit']            = 'Змінити інформацію облікового запису';
$_['text_password']        = 'Змінити пароль';
$_['text_payment']         = 'Змінити Ваші налаштування оплати';
$_['text_tracking']        = 'Партнерський код відслідковування';
$_['text_transaction']     = 'Переглянути історію транзакцій';