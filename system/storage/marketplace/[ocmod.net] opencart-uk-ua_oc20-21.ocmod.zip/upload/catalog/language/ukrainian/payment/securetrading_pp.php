<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

$_['text_title'] = 'Кредитна / Дебетна карта';
$_['button_confirm'] = 'Підтвердити';

$_['text_postcode_check'] = 'Перевірка поштового індексу: %s';
$_['text_security_code_check'] = 'Перевірка CVV2: %s';
$_['text_address_check'] = 'Перевірка адреси: %s';
$_['text_not_given'] = 'Не вказано';
$_['text_not_checked'] = 'Не перевірено';
$_['text_match'] = 'Співпадає';
$_['text_not_match'] = 'Не співпадає';
$_['text_payment_details'] = 'Деталі оплати';

$_['entry_card_type'] = 'Тип карти';