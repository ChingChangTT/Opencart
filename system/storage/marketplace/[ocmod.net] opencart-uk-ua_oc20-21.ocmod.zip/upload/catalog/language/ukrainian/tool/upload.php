<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Text
$_['text_upload']    = 'Ваш файл успішно завантажено!';

// Error
$_['error_filename'] = 'Назва файлу повинна містити від 3 до 64 символів!';
$_['error_filetype'] = 'Неправильний тип файлу!';
$_['error_upload']   = 'Завантаження необхідне!';