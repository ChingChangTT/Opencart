<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title'] = 'Використати подарунковий сертифікат';

// Text
$_['text_success']  = 'Ви успішно використали знижку подарункового сертифікату!';

// Entry
$_['entry_voucher'] = 'Введіть код Вашого подарункового сертифікату тут';

// Error
$_['error_voucher'] = 'Ви ввели неправильний код подарункового сертифікату або сертифікат вже було використано!';
$_['error_empty']   = 'Буль-ласка введіть код подарункового сертифікату!';