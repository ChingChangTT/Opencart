<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Text
$_['text_success']     = 'Ви успішно використали бонусні бали!';

// Error
$_['error_permission'] = 'У Вас немає доступу до API!';
$_['error_reward']     = 'Будь-ласка введіть суму бонусних балів, які Ви хочете використати для оплати!';
$_['error_points']     = 'У Вас немає %s бонусних балів!';
$_['error_maximum']    = 'Максимальна кількість бонусних балів, які Ви можете використати для оплати становить %s!';