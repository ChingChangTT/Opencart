<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']    = 'Підписка на розсилання новин';

// Text
$_['text_account']     = 'Обліковий запис';
$_['text_newsletter']  = 'Розсилання новин';
$_['text_success']     = 'Вашу підписку успішно оновлено!';

// Entry
$_['entry_newsletter'] = 'Підписатися:';