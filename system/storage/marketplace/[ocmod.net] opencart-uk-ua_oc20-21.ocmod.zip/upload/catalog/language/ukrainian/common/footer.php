<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Text
$_['text_information']  = 'Інформація';
$_['text_service']      = 'Сервісні служби';
$_['text_extra']        = 'Додатково';
$_['text_contact']      = 'Контакти';
$_['text_return']       = 'Повернення';
$_['text_sitemap']      = 'Мапа сайту';
$_['text_manufacturer'] = 'Бренди';
$_['text_voucher']      = 'Подарункові сертифікати';
$_['text_affiliate']    = 'Партнерська програма';
$_['text_special']      = 'Спеціальні пропозиції';
$_['text_account']      = 'Обліковий запис';
$_['text_order']        = 'Історія замовлень';
$_['text_wishlist']     = 'Список побажань';
$_['text_newsletter']   = 'Розсилання новин';
$_['text_powered']      = 'Створено <a href="https://ocmod.net">OpenCart</a><br /> %s &copy; %s';