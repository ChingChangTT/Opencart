<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']    = 'Обліковий запис';

// Text
$_['text_register']    = 'Зареєструватися';
$_['text_login']       = 'Вхід';
$_['text_logout']      = 'Вихід';
$_['text_forgotten']   = 'Забули пароль?';
$_['text_account']     = 'Обліковий запис';
$_['text_edit']        = 'Змінити профіль';
$_['text_password']    = 'Пароль';
$_['text_address']     = 'Адресна книга';
$_['text_wishlist']    = 'Список побажань';
$_['text_order']       = 'Історія замовлень';
$_['text_download']    = 'Завантаження';
$_['text_reward']      = 'Бонусні бали';
$_['text_return']      = 'Повернення';
$_['text_transaction'] = 'Оплати';
$_['text_newsletter']  = 'Розсилання новин';
$_['text_recurring']   = 'Регулярні платежі';