<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title']      = 'Ваші транзакції';

// Column
$_['column_date_added']  = 'Дата створення';
$_['column_description'] = 'Опис';
$_['column_amount']      = 'Сума (%s)';

// Text
$_['text_account']       = 'Обліковий запис';
$_['text_transaction']   = 'Ваші транзакції';
$_['text_total']         = 'Ваш поточний баланс становить:';
$_['text_empty']         = 'У Вас немає жодних транзакцій!';