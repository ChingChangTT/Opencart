<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Text
$_['text_home']          = 'Головна';
$_['text_wishlist']      = 'Список побажань (%s)';
$_['text_shopping_cart'] = 'Кошик';
$_['text_category']      = 'Категорії';
$_['text_account']       = 'Обліковий запис';
$_['text_register']      = 'Реєстрація';
$_['text_login']         = 'Вхід';
$_['text_order']         = 'Історія замовлень';
$_['text_transaction']   = 'Оплати';
$_['text_download']      = 'Завантаження';
$_['text_logout']        = 'Вихід';
$_['text_checkout']      = 'Оформлення замовлення';
$_['text_search']        = 'Пошук';
$_['text_all']           = 'Переглянути всі';