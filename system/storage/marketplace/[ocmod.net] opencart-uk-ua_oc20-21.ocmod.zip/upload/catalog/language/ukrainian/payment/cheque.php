<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Text
$_['text_title']				= 'Чек / Оплата готівкою';
$_['text_instruction']			= 'Інструкції для оплати Чеком / Готівкою';
$_['text_payable']				= 'Отримувач: ';
$_['text_address']				= 'Адреса: ';
$_['text_payment']				= 'Ваше замовлення буде відправлене після отримання оплати.';