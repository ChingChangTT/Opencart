<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Text
$_['text_success']       = 'Ви успішно змінили покупців';

// Error
$_['error_permission']   = 'У Вас немає доступу до API!';
$_['error_firstname']    = 'Ім`я повинно містити від 1 до 32 символів!';
$_['error_lastname']     = 'Прізвище повинно містити від 1 до 32 символів!';
$_['error_email']        = 'Неправильний E-Mail!';
$_['error_telephone']    = 'Телефон повинен містити від 3 до 32 символів!';
$_['error_custom_field'] = '%s необхідно!';