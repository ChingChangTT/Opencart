<?php

//version 2.0.0.0
//Made by Sirchyk for www.marketplus.if.ua on 16 of october 2014.
//info@marketplus.if.ua

// Heading
$_['heading_title'] = 'Використати бонусні бали(доступно %s)';

// Text
$_['text_success']  = 'Ви успішно використали бонусні бали!';

// Entry
$_['entry_reward']  = 'Бали для використання (Max %s)';

// Error
$_['error_reward']  = 'Будь-ласка введіть кількість балів для використання при оплаті!';
$_['error_points']  = 'У Вас немає %s бонусних балів!';
$_['error_maximum'] = 'Максимальна кількість балів, яка може бути використана в замовленні %s!';